
var motebus = require('motebus');
var os = require('os');

console.log('OS: ',os.platform());
var isWin32 = os.platform() == 'win32';


motebus.on('ready', () => {
	var replyCount = 0;
	console.log("MoteBus Ready.");

	// ================= xMsg Demo =======================
	var xmsg = motebus.xMsg();
	xmsg.open('echo', '', false, (err, result) =>{
		if (result) {

			// Receive message
			xmsg.on('message', (msg) => {
				console.log("  > Message: head=", msg.head, ", body=", msg.body, ", files=", msg.files );


				// Extract files
				console.log('< Extract files');

				var outpath;
				if (isWin32)
					outpath = "D:\\Project\\VOIP\\MoteBus\\Runtime\\Temp";
				else
					outpath = "/home/richard/Project/MoteBus/Runtime/Temp"

				xmsg.extract( msg.head.id, outpath, (err,result) => {
					if (err) {
						console.error(err);
					} else {
						console.log("  > extract id=%s result= %s", msg.head.id, result);	
					}
				});

				replyCount = 1;
				// Reply message
				if (replyCount == 0) {
					replyCount++;
					console.log('< Reply message');
					var body = {"text": "I am doing well. 我很好."};
					xmsg.reply(msg.head, body, [], 10/*Prio*/, 6/*sec*/, (err, tkinfo) => {
						if (err) {
							console.error(err);
						} else {
							console.log("  > tkinfo(Reply) id=%s state= %s", tkinfo.id, tkinfo.state);	
						}
					});
				}
				
			});

			
		    // Send message
			var body = {"text": "drop http://www.yahoo.com.tw"};
			var files;

			if (isWin32) 
				files = ["D:\\Project\\VOIP\\MoteBus\\Runtime\\*.txt"];
			else
				files = ["/home/richard/Project/MoteBus/Runtime/*.txt"];
			/*
				files = ["/home/richard/image1.jpg",
						 "/home/richard/image2.jpg"];
			*/

			function labXMSG(target) {
				console.log('< Send message');
				xmsg.send(target, body, files, 10/*Prio*/, 6/*sec*/, (err, tkinfo) => {
					if (err) {
						console.error(err);
					} else {
						if (tkinfo.state != 'Reply') {
							console.log("  > tkinfo(send) id=%s, state= %s", tkinfo.id, tkinfo.state);	
						} else {
							console.log("  > tkinfo(send) id=%s, state= %s, body=", 
								tkinfo.id, tkinfo.state, tkinfo.msg.body, ", files=", tkinfo.msg.files);
						}
					}
				});
			};

			function labXMSGWithTimer(target,interval) {
				labXMSG(target);
				setTimeout(function(){
					labXMSGWithTimer(target,interval);
				},interval);
			}

			//labXMSG('echo@hello.ypcall.com:6788');
			//labXMSG('echo@192.168.0.55');
			//labXMSG('echo@202.153.173.253:6788');
			//labXMSG('echo');
			//labXMSGWithTimer('echo', 2000);
		}
	});
	// ==================================================


	// ================= xRPC Demo =======================

	var xrpc = motebus.xRPC();

	// Service functions
	xrpc.publish( 'AIlab', {
		"echo": function(head, text) {
			console.log("  AIlab.echo (",text,")","\n");
			return text;
		},

		"hello": (head, msg1, msg2) => {
			console.log("  AIlab.hello(", msg1, ", ", msg2, ")");
			//throw "myError";
			return "hi";
		},

		"login": (head, user, pass) => {
			console.log("  AIlab.login()");
			return true;
		},

		"logout": (head) => {
			console.log("  AIlab.logout()");
			return true;
		},
		"add": (head, msg1, msg2) => {
			c = add(msg1,msg2);
			console.log("number :",c);
			return c;
		},

		"time": (head, msg1) => {
			var nowDateObj = new Date();//目前時間
			nowDateObj.setDate(nowDateObj.getDate());//增加一天
			var Hour       = nowDateObj.getHours();//取得時
			var Minute     = nowDateObj.getMinutes();//取得分
			var Second      = nowDateObj.getSeconds();//取得秒		
			console.log("  AIlab.time(",msg1 ,Hour,":",Minute,":",Second,")","\n");
			var all = msg1 +" "+ Hour+":"+Minute+":"+Second;
			return all;
		},
		"mqtts": (head, A, B) => {

			var mqttt = require('./prog/mqtt.js');
			mqttt.mqttw(A,B);

			return B;
		}
	})
	.then((result)=>{
		console.log("  publish result:", result);
	})
	.catch((err)=>{
		console.error(err)
	});


	// Call remote function
	function labXRPC(target) {
		//xrpc.call( target, "add", ["12","25"], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "echo", ["Welcome to AIlab"], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "time", ["Now is"], 10/*Prio*/, 6/*sec*/ )

		xrpc.call( target, "mqtts", ["screen/demo","notify YI 60 red 4"], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "mqtts", ["screen/demo","drop https://www.youtube.com/watch?v=09R8_2nJtjg"], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "mqtts", ["sonoff/e89160/power","on"], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "mqtts", ["sonoff/e89160/power","off"], 10/*Prio*/, 6/*sec*/ )


		//xrpc.call( target, "mbus", [{"target":"demo","data":"notify \"Hello YI ~~\" 60 red 4"}], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "mbus", [{"target":"demo","data":"drop https://www.youtube.com/watch?v=09R8_2nJtjg"}], 10/*Prio*/, 6/*sec*/ )
		//xrpc.call( target, "time", ["Now is"], 10/*Prio*/, 6/*sec*/ )
		.then((result)=>{
			console.log("    call result:", result);
		})
		.catch((err)=>{
			console.log("    call error:", err);
			console.log('??');
		});
	}


	function labXRPCWithTimer(target,interval) {
		labXRPC(target);
		setTimeout(function(){
			labXRPCWithTimer(target,interval);
		},interval);
	}

	function add(A,B) {
		var a = parseInt(A);
		var b = parseInt(B);
		var c ;
		c = a + b;
		return c;
	}

	//labXRPC("AIlab@hello.ypcloud.com:6780");
	//labXRPC("AIlab@192.168.0.55");
	//labXRPC("AIlab@192.168.8.7");
	labXRPC("AIlab@127.0.0.1");
	//labXRPC("AIlab@192.168.10.149:6780");
	//labXRPC("AIlab");
	//labXRPC("xhub@202.153.173.254:6788");//xmsg mbus
	//labXRPCWithTimer('AIlab', 2000);
});
