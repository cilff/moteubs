# motebus

MoteBus is a message transport bus for peer-to-peer communication. It supports xMsg, xRPC, xOBj and xSync protocols.
