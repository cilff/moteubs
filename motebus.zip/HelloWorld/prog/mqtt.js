var exports = module.exports = {};
var mqtt = require('mqtt');

 exports.mqttw = function(topic,payload) {

        var client  = mqtt.connect('mqtt://mqtt.cc:1883');
        client.on('connect', function () {
            client.publish(topic, payload);
        })
 
        client.on('message', function (topic, payload) {
        // message is Buffer
        //console.log(payload);
        client.end();
        })

}