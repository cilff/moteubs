var exports = module.exports = {};
var inlayer;

// The routine for send message of motebus

exports.Sendxmsg = function( target, data ){
    inlayer.sendxmsg( target, '', '', data, [], 
        function(result)
        {
            console.log('sendxmsg result=%s', JSON.stringify(result));
        }, 
        function(reply){
            console.log('sendxmsg reply=%s', JSON.stringify(reply));
        }
    );
}
var Sendxmsg = function( target, data ){
    inlayer.sendxmsg( target, '', '', data, [], 
        function(result)
        {
            console.log('sendxmsg result=%s', JSON.stringify(result));
        }, 
        function(reply){
            console.log('sendxmsg reply=%s', JSON.stringify(reply));
        }
    );
}  



exports.init = function(appname, mcenter, host, port){
    console.log('start');
    inlayer = require('../in/in.js');
    inlayer.init(appname, mcenter,
        function(result){
            console.log('init result=%s', JSON.stringify(result));
            //inlayer.gethandler( Getxmsg );
            inlayer.regtoCenter( '', appname, '.app', '', 
                function(reply){
                    if ( reply.ErrCode == 0 ){
                        var mdjinfo = inlayer.getinfo({"request":"getmymote"});
                        Sendxmsg( 'yuanss', 'notify Hello 60 red 4' );
                        return 'ok';
                    }
                } 
            );
        }
    );

}

//-------------------------------------
//xrpc.call( target, "notifys", ["yuanss","notify Hello 60 red 4"], 10/*Prio*/, 6/*sec*/ )

/*
        "notifys": (head, name, msgs) => {

            var toscreen = require('./func/mScreen.js')
            var fs = require('fs');
            console.log('notify');
            var conf = JSON.parse(fs.readFileSync(__dirname +'/config/config.json', 'utf8'));
            //console.log('name=$s,$s',conf.appname,conf.mcenter);

            toscreen.init(conf.appname,conf.mcenter,'','',function(err)
                {

                    return msgs;
                });
            
        }


*/
