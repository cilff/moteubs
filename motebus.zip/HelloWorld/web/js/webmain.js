// main 

var myddn = '';

$(function(){
    // init login routine
    $.login.init( loginOK, logoutOK );
    $.login.checkit();
    // setup get message routine
    $.wsock.init( wsInOK, regmOK, wsErr );
    $.wsock.msgHandler( getMsg );
    // page event handler
    $('#main_nav').on('click', function(e){
        e.preventDefault();
        startMain();
    });
    $('#set_nav').on('click', function(e){
        e.preventDefault();
        startSetting();
    });
    $('#near_nav').on('click', function(e){
        e.preventDefault();
        getMotelist();
    });
    $('#logout_nav').on('click', function(e){
        e.preventDefault();
        doLogout();
    });
    $('#mbus_nav').on('click', function(e){
        e.preventDefault();
        startmbus();
    });
    $('#xrpc_nav').on('click', function(e){
        e.preventDefault();
        startxrpc();
    });
    // button event handler
    $('#send_btn_disp').on('click', function(e){
        e.preventDefault();
        doSendMsg();
    });
    $('#clear_btn_disp').on('click', function(e){
        e.preventDefault();
        clearConsole();
    });
    $('#save_btn_setting').on('click', function(e){
        e.preventDefault();
        saveMotesetting();
    });
    $('#send_btn_xrpc').on('click', function(e){
        e.preventDefault();
        doSendXrpc();
    });
    $('#clear_btn_xrpc').on('click', function(e){
        e.preventDefault();
        clearConsole();
    });
});

// login uCenter OK callback
var loginOK = function(data){
    //alert('loginOK: ' + JSON.stringify(data));
    $('#nav_page').show();
    $('#disp_page').show();
    $.con.out('login OK','state');
}
// logout uCenter OK callback
var logoutOK = function(data){
    $('#nav_page').hide();
    $('#disp_page').hide();
}

// connect and register to websocket server OK callback
var wsInOK = function(result){
    var str = 'regtoIN OK' + ' ' + result.numUsers.toString();
    $.con.out(str,'state');
}

var wsErr = function(result){
    $.con.out(result,'state');
}

// register to mCenter OK callback
var regmOK = function(result){
    var str = 'regtoCenter' + ' ' + result.ErrMsg;
    $.con.out(str,'state');
    buildDevicelist();
    buildMsglist();
    buildArglist();
    buildSettingvalue();
    $.mbus.xrpcStart(function(result){
        str = 'xrpc start: ' + result;
        $.con.out(str, 'state');
    });    
} 

var startMain = function(){
    $('#set_page').hide();
    $('#disp_page').show();
}

var startmbus = function(){
    $('#mbusdiv').show();
    $('#xrpcdiv').hide();
}

var startxrpc = function(){
    $('#xrpcdiv').show();
    $('#mbusdiv').hide();
}

// routine for send button clicked
var doSendMsg = function(){
    var to, data, str;
    
    to = $('#to_disp').val();
    data = $('#msg_disp').val();
    //alert('send cmd: to=' + to + ',msg=' + msg);
    if ( to != '' && data != ''){
        str = to + " " + data;
        $.con.out(str,'send');
        sendMsg(to, data);
    }
}

// send x-message through websocket 
var sendMsg = function(to, data){
    $.wsock.sendSocketUserMsg(to, data);
}

// get x-message from websocket
var getMsg = function(from, data){
    if ( typeof data == 'object'){
        $.con.out(from + ' ' + JSON.stringify(data),'rcve');
    }
    else if ( typeof data == 'string'){
        $.con.out(from + ' ' + data, 'rcve');
    }
    
    if ( typeof data == 'string' ){
        if ( data.indexOf('response') < 0 ) sendMsg( from, 'response: OK')
    }
}

var doSendXrpc = function(){
    var app, func, args, str;
    app = $('#app_xrpc').val();
    func = $('#func_xrpc').val();
    args = $('#arg_xrpc').val();
    if ( app != '' && func != '' && args != '' ){
        str = app + " " + func + " " +  args;
        $.con.out(str,'send');
        $.mbus.xrpcCall(app, func, args,
            function(result) {
                $.con.out('xprcCall result=' + result, 'rcve');
            }
        );
    }
    else {
        $.con.out('xrpc: invalid input', 'state');
    }
}

var startSetting = function(){
    //alert('startSetting');
    $('#disp_page').hide();
    $('#set_page').show();
}

var buildDevicelist = function(){
    var i, len, dev, dname, dtype;
    $('#dev_select').off('change');
    $('#dev_select').empty();
    //$('#dev_select options').remove();
    var options = '<option value="" style="background-color:gray">Select device</option>';
    len = $.mbus.mlist.length;
    for (i = 0; i < len; i++) {
        dname = $.mbus.mlist[i].dname;
        dtype = $.mbus.mlist[i].dtype;
        if ( dname == $.mdevice.dname )
            options += '<option value="' + i.toString() + '">' + dname + ' [' + dtype + '] (self)</option>';
        else
            options += '<option value="' + i.toString() + '">' + dname + ' [' + dtype + '] </option>';
    }
    $("#dev_select").html(options);
    $("#dev_select").on('change',function(e){
        e.preventDefault();
        //alert('select: ' + this.value);
        var v = this.value;
        if ( v != ''){
            var index = parseInt(v);
            var str = $('#to_disp').val();
            if ( str == '' ) str = $.mbus.mlist[index].dname;
            else str += ',' + $.mbus.mlist[index].dname;
            $('#to_disp').val(str);
        }
    });
}

var buildMsglist = function(){
    var i, len, dev;
    $('#msg_select').off('change');
    $('#msg_select').empty();
    var options = '<option value="" style="background-color:gray">Select sample</option>';
    len = msgsample.length;
    for (i = 0; i < len; i++) {
        options += '<option value="' +
            i.toString() + '">' +
            msgsample[i].name +
            '</option>';
    }
    $("#msg_select").html(options);
    $("#msg_select").on('change',function(e){
        e.preventDefault();
        //alert('select: ' + this.value);
        var v = this.value;
        if ( v != ''){
            var index = parseInt(v);
            var str = msgsample[index].cmd;
            $('#msg_disp').val(str);
        }
    });
}

var buildArglist = function(){
    var i, len, dev;
    $('#arg_select').off('change');
    $('#arg_select').empty();
    var options = '<option value="" style="background-color:gray">Select sample</option>';
    len = argsample.length;
    for (i = 0; i < len; i++) {
        options += '<option value="' +
            i.toString() + '">' +
            argsample[i].name +
            '</option>';
    }
    $("#arg_select").html(options);
    $("#arg_select").on('change',function(e){
        e.preventDefault();
        //alert('select: ' + this.value);
        var v = this.value;
        if ( v != ''){
            var index = parseInt(v);
            var data = argsample[index].data;
            var str = JSON.stringify(data);
            $('#arg_xrpc').val(str);
        }
    });
}

var buildSettingvalue = function()
{
    $('#set_address').val($.mdevice.address);
    $('#set_face').val($.mdevice.face);
    $('#set_ddn').val($.mdevice.ddn);
    $('#set_owner').val($.mdevice.owner);
    $('#set_name').val($.mdevice.dname);
    $('#set_type').val($.mdevice.dtype);
    $('#set_tag').val($.mdevice.dtag);
    $('#set_location').val($.mdevice.location);
    $('#set_mirror').val($.mdevice.mirror);
    $('#set_moteweb').val($.mdevice.moteweb);
    $('#set_appweb').val($.mdevice.appweb);
    $('#set_appdata').val($.mdevice.appdata);
}

var saveMotesetting = function()
{
    var ddn = $.mdevice.ddn;
    var appsettings = {"address":"","face":"","ddn":"","owner":"","dname":"","dtype":"","dtag":"","location":"","mirror":"","moteweb":"","appweb":"","appdata":""};
    if ( ddn != '' ){
        appsettings.ddn = ddn;
        appsettings.owner = $.mdevice.owner;
        appsettings.dname = $.mdevice.dname;
        appsettings.dtype = $.mdevice.dtype;
        appsettings.address = $('#set_address').val();
        appsettings.face = $('#set_face').val();
        appsettings.dtag = $('#set_tag').val();
        appsettings.location = $('#set_location').val();
        appsettings.mirror = $('#set_mirror').val();
        appsettings.moteweb = $('#set_moteweb').val();
        appsettings.appweb = $('#set_appweb').val();
        appsettings.appdata = $('#set_appdata').val();
        $.mdevice.saveinfo( appsettings, 
            function(obj){
                BootstrapDialog.alert('saveMotesetting: ' + obj.ErrMsg);
            }, 
            function(){
                BootstrapDialog.alert('saveMotesetting: ' + obj.ErrMsg);
            }
        
        );
    }
}

var doLogout = function(){
    $.login.logout();
}

var getMotelist = function() {
    $.mbus.getmDevice(function(obj){
        if ( typeof obj == 'object'){
            //BootstrapDialog.alert('nearby: ' + JSON.stringify(obj));
            var dname, dtype, k;
            if ( obj.ErrCode == 0 && obj.motecount > 0 ){
                var str = '';
                var len = obj.mote.length;
                for ( var i = 0; i < len ; i++ ){
                    k = i+1;
                    dname = obj.mote[i].dname;
                    dtype = obj.mote[i].dtype;
                    if(dname == $.mdevice.dname)
                        str += k.toString() + '. ' + dname + ' [' + dtype + '] (self)\n';
                    else
                        str += k.toString() + '. ' + dname + ' [' + dtype + '] \n';
                }
                BootstrapDialog.alert({"title":"NearBy","message":str});
                buildDevicelist();
            } 
            else {
                BootstrapDialog.alert('nearby: ' + obj.ErrMsg);    
            }
        }
    });
}

var clearConsole = function()
{
    $.con.clear();
}



