// webpipe module for websokcet client operation
// Date: 2017/9/20
// Version: 0.96

var socket;
var firstconn = true;
socket = io(
    {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax : 5000,
        reconnectionAttempts: Infinity
    }
);

// class

$.wsock = {
    wsState: '',
    socketState: 'idle',
    wsNotify: null,
    mregNotify: null,
    rcveHandler: null,
    errHandler: null,
    init: function( wcb, mcb, errcb ){
        if ( typeof wcb === 'function' )
            $.wsock.wsNotify = wcb;
        if ( typeof mcb === 'function' )
            $.wsock.mregNotify = mcb;
        if ( typeof errcb === 'function' )
            $.wsock.errHandler = errcb;
        $.login.minit($.wsock.afterLogin, $.wsock.afterLogout);
    },
    afterLogin: function(data){
        if ( $.wsock.wsState != 'conn' ) return;
        $.wsock.regIN(data, 
            function(result){
                if ( typeof $.wsock.wsNotify === 'function' ) $.wsock.wsNotify(result);
                $.mdevice.getinfo(
                    function(mdata){
                        // register to mCenter
                        //alert('register to mCenter')
                        $.mbus.regtoCenter( function(result){
                            //alert('regtoCenter reply='+JSON.stringify(data));
                            if ( typeof $.wsock.mregNotify === 'function' ) $.wsock.mregNotify(result);
                        });
                    }
                );
            }
        );
    },
    afterLogout: function(data){
        //alert('afterLogout data=' + JSON.stringify(data));
        $.mbus.unregtoCenter(data.ddn, 
            function(reply){
                if ( reply.ErrCode == 0 ){
                    $.wsock.unregIN('logout', 
                        function(result){
                            //alert('unregIN result=' + JSON.stringify(result));
                        }
                    );
                }
            }
        );
    },
    regIN: function(data, cb) {
        var usrinfo = {"ddn":"","username":"","token":"","dname":""};
        //alert('connect to socket server');
        if (data.username) {
            usrinfo.ddn = data.ddn;
            usrinfo.username = data.username;
            usrinfo.token = data.uid;
            usrinfo.dname = data.device_name;
            // Tell the server your username
            //alert('usrinfo='+JSON.stringify(usrinfo));
            //socket.emit('add user', usrinfo);
            if ( $.wsock.wsState != 'conn' ) return;
            socket.emit('user', {"request":"adduser","usrinfo": usrinfo}, 
                function(data){
                    //alert('regIN ack='+JSON.stringify(data));
                    $.wsock.socketState = 'conn';
                    if ( typeof cb == 'function') cb (data);
                }
            );
        }
    },
    unregIN: function(data, cb){
        //socket.emit('remove user',data);
        if ( $.wsock.socketState != 'conn' ) return;
        socket.emit('user', {"request":"rmuser","usrinfo": data},
            function(reply){
                if ( typeof cb == 'function') cb (reply);
            }
        );
    },
    sendSocketUserMsg: function(to, data) {
        try {
            if ( $.wsock.socketState == 'conn'){
                var reqdata = {"cmd":"send","target":to,"data":data};
                socket.emit('request', reqdata);
            }
        }
        catch(e){
            if ( typeof $.wsock.errHandler == 'function' )
                $.wsock.errHandler(e.message);
        }
    },
    sendSocketUserMsgReply: function(to, data, callback) {
        try {
            if ( $.wsock.socketState == 'conn'){
                var reqdata = {"cmd":"send","target":to,"data":data};
                socket.emit('request', reqdata, callback);
            }
        }
        catch(e){
            if ( typeof $.wsock.errHandler == 'function' )
                $.wsock.errHandler(e.message);
        }
    },
    sendSocketMsg: function(data) {
        try {
            if ( $.wsock.socketState == 'conn'){
                if ( typeof data == 'object' ){
                socket.emit('request', data);
                }
            }
            else alert('websocket not ready');
        }
        catch(e){
            if ( typeof $.wsock.errHandler == 'function' )
                $.wsock.errHandler(e.message);
        }
    },
    sendSocketMsgReply: function(data, callback) {
        try {
            if ( $.wsock.socketState == 'conn'){
                if ( typeof data == 'object' ){
                    socket.emit('request', data, callback);
                }
            }
            else {
                if ( typeof $.wsock.errHandler == 'function' )
                    $.wsock.errHandler('websocket not ready');
                else
                    alert('websocket not ready');
            }
        }
        catch(e){
            if ( typeof $.wsock.errHandler == 'function' )
                $.wsock.errHandler(e.message);    
        }
    },
    msgHandler: function(cb){
        if ( typeof cb === 'function')
            $.wsock.rcveHandler = cb; 
    },
    socketReconnect: function(){
        var data = {"ddn":$.login.ddn,"username":$.login.username,"token":$.login.uid,"dname":$.login.device_name};
        if ( $.wsock.wsState != 'conn' ) return;
        $.wsock.regIN(data, 
            function(result){
                if ( typeof $.wsock.wsNotify === 'function' ) $.wsock.wsNotify(result);
                $.mdevice.getinfo(
                    function(mdata){
                        // register to mCenter
                        //alert('register to mCenter')
                        $.mbus.regtoCenter( function(result){
                            //alert('regtoCenter reply='+JSON.stringify(data));
                            if ( typeof $.wsock.mregNotify === 'function' ) $.wsock.mregNotify(result);
                        });
                    }
                );
            }
        );
    },
};

$.mbus = {
    mlist: [],
    regtoCenter: function( cb ){
        $.wsock.sendSocketMsgReply({"cmd":"regmcenter","ddn":$.mdevice.ddn,"dname":$.mdevice.dname,"dtype":$.mdevice.dtype,"dtag":$.mdevice.dtag},
            function(data){
                var mote = [];
                //alert( 'register to mCenter=' + JSON.stringify(data) );
                if ( data.err == 'none' && data.body.ErrCode == 0 ){
                    $.mbus.mlist = [];
                    mote = data.body.mote;
                    $.mbus.mlist = mote.slice();
                }
                //alert( 'register to mCenter=' + JSON.stringify($.mbus.mlist) );
                if ( typeof cb == 'function' ) {
                    cb(data.body);
                }
            }
        );    
    },
    unregtoCenter: function( ddn, cb ){
        //alert('unregtoCenter ddn=' + ddn);
        $.wsock.sendSocketMsgReply({"cmd":"unregmcenter","ddn":ddn},
            function(reply){
                //alert('unregtoCenter reply' + JSON.stringify(reply));
                if ( typeof cb == 'function' ) {
                    cb(reply)
                }
            }
        );    
    },
    getmDevice: function(cb) {
	    $.wsock.sendSocketMsgReply({"cmd":"getmdevice"}, 
            function(data){
                var mote;
                if ( data.err == 'none' && data.body.ErrCode == 0 ){
                    $.mbus.mlist = [];
                    mote = data.body.mote;
                    $.mbus.mlist = mote.slice();
                }
                if ( typeof cb == 'function' ) cb(data.body);
			}
		);
    },
    xrpcStart: function(cb){
        $.wsock.sendSocketMsgReply({"cmd":"xrpcStart"}, 
            function(reply){
                if ( typeof cb == 'function' ) cb(reply.body.result);
            }
        );
    },
    xrpcCall: function(app, func, args, cb){
        $.wsock.sendSocketMsgReply({"cmd":"xrpcCall","app":app,"func":func,"args":args}, 
            function(reply){
                if ( typeof cb == 'function' ) cb(reply.body.result);
            }
        );
    }
}

// socket handler

socket.on('connect_error', function(error){
    if ( typeof $.wsock.errHandler == 'function' )
        $.wsock.errHandler('websocket connect error');
    else
        alert('websocket connect error');
});

socket.on('connect_timeout', function(timeout){
    if ( typeof $.wsock.errHandler == 'function' )
        $.wsock.errHandler('websocket connect timeout');
    else
        alert('websocket connect timeout');
});

socket.on('connect', function(){
    $.wsock.wsState = 'conn';
    if ( firstconn == true ) {
        if ( typeof $.wsock.errHandler == 'function' )
            $.wsock.errHandler('websocket connected');
        firstconn = false;
    }
    else {
        if ( typeof $.wsock.errHandler == 'function' )
            $.wsock.errHandler('websocket re-connected');
        $.wsock.socketReconnect();
    }   
});

socket.on('disconnect', function(){
    if ( typeof $.wsock.errHandler == 'function' )
        $.wsock.errHandler('websocket disconnect');
    else
        alert('websocket disconnect');
});

socket.on('error', function(err){
    if ( typeof $.wsock.errHandler == 'function' )
        $.wsock.errHandler('websocket error='+JSON.stringify(err));
    else
        alert('websocket error='+JSON.stringify(err));
});

socket.on('message', function (body) {
    //recevive cmd from server
    if ( typeof body == 'object'){
        //alert('recv message object='+ JSON.stringify(data));
        if ( typeof $.wsock.rcveHandler == 'function') {
            var inctl = body.in;
            var data = body.data;
            var from = inctl.fm;
            $.wsock.rcveHandler(from, data);
        }
    }
});
