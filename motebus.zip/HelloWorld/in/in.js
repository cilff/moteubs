// in module for motebus
// Date: 2017/10/18
// Version: 0.97

var exports = module.exports = {};
var mbus;
var inmsgcb;

// appname: app name used as MMA, mcenter: the MMA of mCenter,
// gethandler: the handler routine of incoming message, cb: init result callback
exports.init = function( appname, mcenter, cb ){
	console.log('in.init');
    try {
        mbusinit(appname, mcenter, 
            function(result){
                if ( typeof cb == 'function') cb(result);
            }
        );
    }
    catch(e){
        console.log('init error=%s', e.message);
        if ( typeof cb == 'function' ) cb({"ErrCode":-254,"ErrMsg":e.message});
    }
}

exports.gethandler = function(cb){
    if ( typeof cb == 'function')
        inmsgcb = cb;
}

var inmsghandler = function(msg){
    try {
        //console.log('inmsghandler msg=%s', JSON.stringify(msg));
        if ( typeof inmsgcb == 'function') {
            var head = msg.head;
            var body = msg.body;
            var inctl = body.in;
            var data = body.data;
            var fm = inctl.fm;
            if ( fm == '' ) {
                fm = head.from;
                fm = fm.substr(0, fm.indexOf(';'));
			}
			if ( getdeviceinfo(fm, "ddn") == null ) {
				getmdevice();
			}
            inmsgcb( head, fm, inctl.to, data );
        }    
    }
    catch(e){
        console.log('inmsghandler error=%s', e.message);
    }
}

// target: MMA, to: DDN of destination, data: data object sent, 
// files: files sent, cb: result callback, rcb: destination reply callback  
exports.sendxmsg = function( target, fm, to, data, files, cb, rcb ){
    var mma, to;
    var tarr = [];      // target list
    var marr = [];      // mma list
	try {
        if ( target != '' && data != ''){
            var body = {"in":{"fm":fm,"to":to,"msgtype":""},"data":data};
            if ( target.indexOf(',') > 0 ) tarr = target.split(',');
            else tarr[0] = target;
            for ( var i = 0; i < tarr.length; i++ ){
				console.log('sendxmsg: target=%s', JSON.stringify(tarr[i]));
                if ( target.indexOf('@') > 0 ) {
					mma = getWorkmma(tarr[i]);
                    marr.push({"ddn":"","mma":mma});
                }
                else {
					to = searchmma(tarr[i]);
                    console.log('sendxmsg: to=%s', JSON.stringify(to));
                    if ( to.mmacount > 0 ){
                        //console.log('->%s: to=%s', CurrentTime(), JSON.stringify(to.mmalist));
                        marr = to.mmalist;
                    }
                }
                if ( marr.length > 0){
                    for ( var k = 0; k < marr.length; k++){
						body.in.to = marr[k].ddn;
						mma = marr[k].mma;
                        dosendxmsg( mma, body, [], cb, rcb );   
                    }
                }
            }
        }
        else {
            console.log('Sendxmsg: empty target or data');
        }
    }
	catch(e){
        console.log('sendxmsg error=%s', e.message);
        if ( typeof cb == 'function' ) cb({"ErrCode":-254,"ErrMsg":e.message});
    }
}

var dosendxmsg = function(to, body, files, cb, rcb){
    console.log('dosendxmsg: to=%s', to);
    sendxmsg( to, body, files, cb, 
        function(msg){
            if ( typeof rcb == 'function'){
                var head = msg.head;
                var body = msg.body;
                var inctl = body.in;
                var data = body.data;
                var from = inctl.fm;
                if ( from == '' ) {
                    from = head.from;
                    from = from.substr(0, from.indexOf(';'));
                }
                rcb( head, from, inctl.to, data );
            }
        }
    );  
}

// head: hearder of incoming message, fm: DDN of destination, data: data object sent, 
// cbOK: OK callback, cbFail: fail callback  
exports.replyxmsg = function( head, fm, to, data, cbOK, cbFail ){
    var body = {"in":{"fm":fm,"to":to},"data":data};
    try {
        replyxmsg( head, body, cbOK, cbFail );
    }
    catch(e){
        console.log('replyxmsg error=%s', e.message);
        if ( typeof cbFail == 'function' ) cbFail({"ErrCode":-254,"ErrMsg":e.message});
    }
}

exports.regtoCenter = function(ddn, dname, dtype, dtag, cb){
    regtoCenter( ddn, dname, dtype, dtag,
        function(reply){
            if ( typeof cb == 'function' ) cb(reply);
        }
    );
}

exports.unregtoCenter = function(ddn, cb){
    unregtoCenter( ddn,
        function(reply){
            if ( typeof cb == 'function' ) cb(reply);
        }
    );
}

exports.getinfo = function( req, cb ) {
    return getinfo( req, function(data){
        if ( typeof cb == 'function' ){
            cb(data);
        }
    });
}


var getinfo = function( req, cb ){
    var request = req.request;
    if ( request != '' ) {
        request = request.toLowerCase();
        switch(request){
            case 'getmdevice':
                getmdevice(
                    function(reply){
                        if ( typeof cb == 'function' ) cb(reply);
                    }
                );
                break;
            case 'searchmma':
                var search = req.search;
                return searchmma( search );
                break;
            case 'getworkmma':
                var target = req.target;
                return getWorkmma( target );
                break;
            case 'getdname':
                var ddn = req.ddn;
                return getdname( ddn );
            case 'getmymote':
                return getmymote();
                break;
            default:
                break;
        }
    }
    return null;
}

// modules for mbus

var xmsg;
var xmsgstate = '';
var mCenter = '';
var mmalist = [];
var mymote;
var motebus;
var motebusid = '';

var mbusinit = function( userid, mcenter, cb ){
	motebusid = userid;
	mCenter = mcenter;
	motebus = require('motebus');
	console.log('var mbusinit');
	motebus.on('ready', function() {
		console.log( '--%s: MoteBus Ready', CurrentTime());
		xmsgstate = 'ready';
		console.log('motebus.on into');
		openxmsg( motebus, motebusid, cb );
	});
}

var openxmsg = function( motebus, userid, cb ){
	xmsg = motebus.xMsg();
	console.log('var openxmsg');
	xmsg.open( userid, '', false, function( err, result ){
		//console.error(err);
		console.log( '--%s: MoteBus open=%s', CurrentTime(), result);
		xmsgstate = 'opened';
		if ( typeof cb == 'function' ) cb( result );
	});

	xmsg.on('message', function(msg) {
		//console.log("Incoming Message: id=", msg.head.id, ", body=", JSON.stringify(msg.body), ", files=", msg.files );
		console.log('--%s: In Message head=%s,body=%s', CurrentTime(), JSON.stringify(msg.head), JSON.stringify(msg.body));
		if ( msg.head.replyID != ''){
			replyCtl.reply( msg.head.replyID, msg.body );	
		}
		if ( typeof inmsghandler == 'function') {
			inmsghandler( msg );
		}
	});
}

var sendxmsg = function(target, body, files, cb, rcb){
	sendxmsgReply( target, body, files, cb, rcb );  
}  

var sendxmsgReply = function( target, body, files, cb, rcb ){
	console.log('--%s: Send Message target=%s body=%s', CurrentTime(), target, JSON.stringify(body));
	xmsg.send(target, body, files, 10/*Prio*/, 6/*sec*/, 
	  function(err, tkinfo) {
		if (err) {
			//console.error(err);
			console.log('--%s: sendxmsgReply: error=%s', CurrentTime(), JSON.stringify(err));
			if ( typeof cb == 'function') cb(err.message);
		}
		else {
			console.log("--%s: Send Message: tkinfo(send) id=%s, state=%s", CurrentTime(), tkinfo.id, tkinfo.state);
			if (tkinfo.state != 'Reply') {
			//console.log("Send Message: tkinfo(send) id=%s, state=%s", tkinfo.id, tkinfo.state);
			if ( typeof cb == 'function') cb(tkinfo);
				if ( tkinfo.state == 'Sent'){
					if ( typeof rcb == 'function' ) replyCtl.wait(tkinfo.state, tkinfo.id, rcb);
				}
			}
			else {
				console.log("--%s: Send Message Reply: %s", CurrentTime(), JSON.stringify(tkinfo.msg.body) );
				//console.log("%s Send Message Reply: tkinfo(send) id=%s, state=%s, body=%s", 
				//  CurrentTime(), tkinfo.id, tkinfo.state, JSON.stringify(tkinfo.msg.body), ", files=", tkinfo.msg.files);
				if ( typeof rcb == 'function') {
					rcb( tkinfo.msg );
				}
			}
		}
	}); 
}
  
var replyxmsg = function(head, body, cbOK, cbFail ){
	console.log('--%s: Reply Message body=%s', CurrentTime(), JSON.stringify(body));
	xmsg.reply( head, body, [], 10/*Prio*/, 6/*sec*/, function(err, tkinfo) {
		if (err) {
			console.error(err);
			if ( typeof cbFail == 'function' ) cbFail(err);
		} else {
			console.log("--%s: Reply Message: tkinfo(Reply) id=%s state= %s", CurrentTime(), tkinfo.id, tkinfo.state);
			if ( typeof cbOK == 'function' ) cbOK( {"state":tkinfo.state} );	
		}
	});
}


var regtoCenter = function( ddn, dname, dtype, dtag, reply ){
	var target;
	var data = {"cmd":"addmote","mote":{"ddn":ddn,"dname":dname,"dtype":dtype,"dtag":dtag}};
	var body = {"in":{},"data":data};
	var files = [];
	target = mCenter;
	//console.log('--%s: target=%s', CurrentTime(), target);
	//console.log('--%s: body=%s', CurrentTime(), JSON.stringify(body));
	sendxmsgReply( target, body, files, 
		function(result){
		},
		function(msg){
			var body = msg.body;
			console.log('--%s: regtoCenter reply=%s', CurrentTime(), JSON.stringify(body));
			var rdata = body.data;
			if ( rdata.ErrCode == 0 ) {
				mmalist = [];
				mmalist = rdata.mote.slice(0);
				console.log('--%s: mmalist=%s', CurrentTime(), JSON.stringify(mmalist));
				if ( ddn != '' ) getMyInfo(ddn);
				else getMyInfoByName(dname);
			}
			if ( typeof reply == 'function' ) reply(rdata);
		}
	);
}

var unregtoCenter = function( ddn, reply ){
	var target;
	var data = {"cmd":"delmote","mote":{"ddn":ddn}};
	var body = {"in":{},"data":data};
	var files = [];
	target = mCenter;
	sendxmsgReply( target, body, files, 
		function(result){
		},
		function(msg){
			var body = msg.body;
			console.log('--%s: unregtoCenter reply=%s', CurrentTime(), JSON.stringify(body));
			var rdata = body.data;
			if ( rdata.ErrCode == 0 ) {
				mmalist = [];
				mmalist = rdata.mote.slice(0);
				console.log('--%s: mmalist=%s', CurrentTime(), JSON.stringify(mmalist));
			}
			if ( typeof reply == 'function' ) reply(rdata);
		}
	);
}

var getmdevice = function( reply ){
	var target = mCenter;
	var data = {"cmd":"listall"};
	var body = {"in":{"fm":"","to":""},"data":data};
	var files = [];
	sendxmsgReply( target, body, files, 
		function(result){
		},
		function(msg){
			var body = msg.body;
			console.log('--%s: getmdevice reply=%s', CurrentTime(), JSON.stringify(body));
			var rdata = body.data;
			if ( rdata.ErrCode == 0 && rdata.motecount > 0 ) {
				mmalist = rdata.mote.slice(0);
				console.log('--%s: mmalist=%s', CurrentTime(), JSON.stringify(mmalist));
			}
			if ( typeof reply == 'function' ) reply( rdata );
		}
	);
}

var searchmma = function( target ){
	var i, len, mdev, starget, k, tlen;
	var ddn, dname, dtype, dtag;
	var reply = {"ErrCode":0,"mmacount":0,"mmalist":[]};
	var tarr = [];
	var ismatch = false;
	if ( target != '' ){
		console.log('--%s: searchmma: target=%s', CurrentTime(), target);
		tarr = target.split(',');
		tlen = tarr.length;
		for ( k = 0; k < tlen; k++ ){
			starget = tarr[k];
			//console.log('--%s: searchmma: starget=%s', CurrentTime(), starget);
			if ( starget != '' ){ 
				starget = starget.trim().toLowerCase();
				len = mmalist.length;
				for ( i = 0; i < len; i++ ){
					mdev = mmalist[i];
					//console.log('--%s: searchmma: mdev=%s', CurrentTime(), JSON.stringify(mdev));
					ddn = mdev.ddn;
					dname = mdev.dname;
					dtype = mdev.dtype;
					dtag = mdev.dtag;
					if ( ddn != '' ) ddn = ddn.toLowerCase();
					if ( dname != '' ) dname = dname.toLowerCase();
					if ( dtype != '' ) dtype = dtype.toLowerCase();
					if ( dtag != '' ) dtag = dtag.toLowerCase();
					//console.log('--%s: searchmma: ddn=%s dname=%s dtype=%s dtag=%s', CurrentTime(), ddn, dname, dtype, dtag);
					ismatch = false;
					if ( starget == ddn || starget == dname || starget == dtype ) ismatch = true;
					else if ( dtag != '' && dtag.indexOf(starget) >= 0 ) ismatch = true;
					if ( ismatch == true ) {
						mma = getrealmma(mdev);
						var mblock = {"ddn":mdev.ddn,"mma":mma,"udid":mdev.udid,"dtype":mdev.dtype};
						//console.log('--%s: searchmma: mblock=%s', CurrentTime(), JSON.stringify(mblock));
						reply.mmalist.push( mblock );
					}
				}
			}
		}
	}
	reply.mmacount = reply.mmalist.length;
	return reply;
}

var getdname = function( ddn ){
	var i, len;
	len = mmalist.length;
	if ( len > 0 ) {
		for ( i = 0; i < len; i++ ){
			if ( mmalist[i].ddn == ddn ) return mmalist[i].dname
		}
	}
	return ddn;
}

var getmymote = function(){
	return mymote;
}

var getWorkmma = function( target ){
	var mdev;
	var ret = null;
	console.log('--%s getWorkmma: target=%s', CurrentTime(), target);
	mdev = getdeviceinfo( target, 'mma' );
	if ( mdev != null && typeof mdev == 'object'){
		console.log('--%s mdev=%s', CurrentTime(), JSON.stringify(mdev));
		ret = getrealmma( mdev );
	}
	return ret;
}

var getrealmma = function( mdev ){
	var ret = '';
	if ( mdev != null && typeof mdev == 'object'){
		ret = mdev.mma;
		console.log('--%s getrealmma: mdev=%s', CurrentTime(), JSON.stringify(mdev));
		if ( mdev.wanip != '' && mdev.wanip != mdev.host ){
			// target is device under NAT
			if ( typeof mymote == 'object'){
				if ( mymote.wanip == mymote.host || mymote.wanip == '' ){
					// my mote is device at public ip
					ret = ret.substr(0, ret.indexOf('@')+1) + mdev.udid;
				}
			}
			else console.log('--%s getrealmma: no mymote info', CurrentTime());
		}
	}
	return ret;	
}

var getdeviceinfo = function( target, mode ){
	var i, len;
	len = mmalist.length;
	if ( len > 0 ) {
		for ( i = 0; i < len; i++ ){
			if ( mode == 'mma' ){
				if ( target == mmalist[i].mma ) {
					return mmalist[i];
				}
			}
			else if ( mode == 'ddn' ){
				if ( target == mmalist[i].ddn ) {
					return mmalist[i];
				}
			}
		}
	}
	return null;
}

var CurrentTime = function()
{
	var currentdate = new Date(); 
	var datetime = currentdate.getFullYear() + "/" + currentdate.getMonth() + "/" + currentdate.getDate() + " ";
		datetime += currentdate.getHours() + ":" + currentdate.getMinutes() + ":" + currentdate.getSeconds() +":";
		datetime += currentdate.getMilliseconds();
	return datetime;
}

var replyCtl = {
	wqueue: [],
	wait: function(state, id, callto){
		var ix;
		var qcell = {"id":id,"status":"wait","callto":callto};
		ix = replyCtl.check(id);
		if ( ix == -1 ){
			replyCtl.wqueue.push(qcell);
		}
		else {
			if ( state == 'End' && replyCtl.wqueue[ix].status == 'ok'){
				replyCtl.wqueue.splice(ix,1);
			}
		}
	},
	reply: function(id, data){
		var ix = replyCtl.check(id);
		if ( ix >= 0 ){
			if ( replyCtl.wqueue[ix].status == 'wait'){
				replyCtl.wqueue[ix].status = 'ok';
				if ( typeof replyCtl.wqueue[ix].callto == 'function' ) replyCtl.wqueue[ix].callto(data);
				replyCtl.wqueue.splice(ix,1);
				console.log('--%s: reply queue=%s', CurrentTime(), JSON.stringify(replyCtl.wqueue));
			}
		}
		else {
			var qcell = {"id":id,"status":"ok","callto":null};
			replyCtl.wqueue.push(qcell);
		}
	},
	check: function(id){
		var result = -1;
		var len = replyCtl.wqueue.length;
		for ( var i = 0; i < len; i++ ){
			if (replyCtl.wqueue[i].id == id){
				result = i;
				break;
			}
		}
		return result;
	}
}

var getMyInfo = function(ddn){
	var i, len;
	mymote = {"ddn":"","dname":"","dtype":"","dtag":"","host":"","mma":"","udid":"","wanip":""};
	len = mmalist.length;
	for ( i = 0; i < len; i++ ){
		if ( ddn == mmalist[i].ddn ){
			mymote.ddn = mmalist[i].ddn;
			mymote.dname = mmalist[i].dname;
			mymote.dtype = mmalist[i].dtype;
			mymote.dtag = mmalist[i].dtag;
			mymote.host = mmalist[i].host;
			mymote.mma = mmalist[i].mma;
			mymote.udid = mmalist[i].udid;
			mymote.wanip = mmalist[i].wanip;
			break;
		}
	}
	if ( typeof mymote == 'object')
		console.log('--%s: mymote=%s', CurrentTime(), JSON.stringify(mymote));
}

var getMyInfoByName = function(dname){
	var i, len;
	mymote = {"ddn":"","dname":"","dtype":"","dtag":"","host":"","mma":"","udid":"","wanip":""};
	len = mmalist.length;
	for ( i = 0; i < len; i++ ){
		if ( dname == mmalist[i].dname ){
			mymote.ddn = mmalist[i].ddn;
			mymote.dname = mmalist[i].dname;
			mymote.dtype = mmalist[i].dtype;
			mymote.dtag = mmalist[i].dtag;
			mymote.host = mmalist[i].host;
			mymote.mma = mmalist[i].mma;
			mymote.udid = mmalist[i].udid;
			mymote.wanip = mmalist[i].wanip;
			break;
		}
	}
	if ( typeof mymote == 'object')
		console.log('--%s: mymote=%s', CurrentTime(), JSON.stringify(mymote));
}

