// webrelay module for websocket and motebus operation
// Date: 2017/9/15
// Version: 0.96

var exports = module.exports = {};

var numUsers = 0;
var iosocket = [];
var usvr;
var inlayer;

exports.init = function(io, app, mcenter){
  usvr = require('../in/webmote.js');
  inlayer = require('../in/in.js');
  inlayer.init(app, mcenter,
    function(result){
      console.log('init result=%s', JSON.stringify(result));
      inlayer.gethandler(inmsgRecv);
    }
  );
  io.on('connection', function (socket) {
    iosocket.push(socket);
  // when the client emits 'user', this listens and executes
    socket.on('user', function(data, ack){
      var req = data.request;
      var usrinfo = data.usrinfo;
      if ( req == 'adduser'){
          socket.username = usrinfo.username;
          ++numUsers;
          console.log('->%s: %s: adduser %s, userno=%s', CurrentTime(), socket.id, usrinfo.username, numUsers );
          usvr.adduser({"id": socket.id, "ddn": usrinfo.ddn, "username": usrinfo.username, "token": usrinfo.token, "dname": usrinfo.dname});
          if ( typeof ack == 'function' ) ack({"resp":"adduser","numUsers": numUsers, "id": socket.id, "username": usrinfo.username});
          console.log('->%s: %s: add user=%s', CurrentTime(), socket.id, JSON.stringify(usrinfo));
      }
      else if ( req == 'rmuser'){
          console.log('->%s: remove user: reason=%s', usrinfo.reason);
          --numUsers;
          console.log('->%s: remove user %s count=%s', CurrentTime(), socket.id, socket.username, numUsers);
          usvr.rmuser({"id": socket.id, "username": socket.username});
          if ( typeof ack == 'function' ) ack({
            "resp":"rmuser", "numUsers": numUsers, "id": socket.id, "username": socket.username});
      }
    });
      
  // when the user disconnects.. perform this
    socket.on('disconnect', function () {
      //console.log('%s: disconnect=%s',socket.id, socket.username);
      var skid = socket.id;
      var uname = usvr.getuser(skid,'username');
      var ddn = usvr.getuser(skid, 'ddn');
      if (uname != ''){
        //console.log('%s: disconnect=%s',socket.id, socket.username);
        --numUsers;
        console.log('->%s: %s: disconn user %s count=%s', CurrentTime(), skid, uname, numUsers);
        usvr.rmuser({"id": skid, "username": uname});
        inlayer.unregtoCenter(ddn, function(msg){
          console.log('->%s: unregtoCenter result=%s', CurrentTime(), JSON.stringify(msg));
          console.log('->%s: unregtoCenter: %s %s', CurrentTime(), ddn, uname);
        });
      }
      else {
        console.log('->%s: %s: disconnect', CurrentTime(), socket.id );
      }
    });
    
    socket.on('request', function (msg, cb) {
      var cmd, data, token;
      console.log('->%s: %s: request=%s', CurrentTime(), socket.id, JSON.stringify(msg));
      if ( typeof msg.cmd === 'string'){
        cmd = msg.cmd;
        var reply = {"resp":"","err":"","body":{}};
        if ( cmd == 'send' ){
          target = msg.target;
          if ( typeof target == 'string' )
            msgSwitch( socket, target, msg.data, cb ); 
          else
            console.log('->$s: error: %s',CurrentTime(), 'target datatype error' );
        }
        else if ( cmd != '' ){
          reply.resp = cmd;
          reply.err = 'none';
          cmd = cmd.toLowerCase();
          switch(cmd){
            case 'getusers':    // get user info from socket server
              data = usvr.getalluser();
              //console.log('%s: getusers=%s', socket.id, JSON.stringify(data));
              reply.body = data;
              if ( typeof cb == 'function' ) cb(reply);
              break;
            case 'regmcenter':
              inlayer.regtoCenter( msg.ddn, msg.dname, msg.dtype, msg.dtag, 
                function(msg){
                  reply.body = msg;
                  if ( typeof cb == 'function' ) cb(reply);
                } 
              );
              break;
            case 'unregmcenter':
              inlayer.unregtoCenter( msg.ddn, 
                function(reply){
                  if ( typeof cb == 'function' ) cb(reply);
                } 
              );
              break;
            case 'getmdevice':
              inlayer.getinfo({"request":"getmdevice"}, function(msg){
                reply.body = msg;
                if ( typeof cb == 'function' ) cb(reply);
              });
              break;
            case 'xrpcstart':
              //console.log('->%s: xrpcStart', CurrentTime());
              var ret = {"result":""};
              inlayer.xrpcStart(function(xrpc){
                if ( xrpc == null ){
                  ret.result = 'error';
                }
                else {
                  ret.result = 'OK';
                }
                if ( typeof cb == 'function' ) {
                  reply.body = ret;
                  cb(reply);
                }
              });
              break;
            case 'xrpccall':
              var target, func, args;
              target = msg.app;
              func = msg.func;
              args = msg.args;
              if ( target != '' && func != '' && args != ''){
                inlayer.callxrpc( target, func, args, function(result){
                  if ( typeof cb == 'function' ) {
                    var ret = {"result":result};
                    reply.body = ret;
                    cb(reply);
                  }
                });
              }
              else {
                if ( typeof cb == 'function' ) {
                  var ret = {"result":"invalid input"};
                  reply.body = ret;
                  cb(reply);
                }
              }
              break;
            default:
              reply.err = 'Invalid command';
              if ( typeof cb == 'function' ) cb(reply);
              break;
          }
        }
      }
    });
  });

  var msgSwitch = function( socket, target, data, cb ){
    var reply = {"resp":"","err":""};
    console.log('->%s: msgSwitch %s %s', CurrentTime(), target, JSON.stringify(data));
    reply.resp = data.cmd;
    reply.err = 'none';
    if ( typeof cb == 'function' ) cb( reply );
    fm = usvr.getuser( socket.id, 'ddn');
    fdname = usvr.getuser( socket.id, 'dname' );
    if ( target == '' ){
      token = usvr.getuser( socket.id, 'token' );
      socket.emit( 'message',{"in":{"fm":"self"},"data":data} );    
    }
    else {
      inlayer.sendxmsg(target, fm, '', data, [], 
        function(msg){
        },
        function(head, fm, to, data){
          console.log( '->%s: receive from=%s', CurrentTime(), fm );
          inmsgRecv(head, fm, to, data);
        }
      );
    }
  }
    
  var inmsgRecv = function(head, from, to, data){
    var id, mfrom;
    var socket;
    try {
      //console.log('%s: receive from=%s data=%s', CurrentTime(), from, JSON.stringify(data));
      if ( typeof from == 'string' && typeof to == 'string' ){
        mfrom = '';
        if ( from != '' ){
          if ( from.indexOf('@') < 0 ) mfrom = from;
          else {
            mfrom = inlayer.getinfo({"request":"getdname","ddn":mfrom});
            console.log('->%s: dname=%s', CurrentTime(), mfrom);
          }
        }
        id = usvr.getsocketid( to, 'ddn' );
        if ( id != '' ){
          // ddn is in socket server
          if ( typeof data === 'object')
            console.log('->%s: receive object fm: %s data=%s', CurrentTime(), mfrom, JSON.stringify(data) );
          else if ( typeof data === 'string')
            console.log('->%s: receive string fm: %s data=%s', CurrentTime(), mfrom, data );
          else {
            console.log('->%s: receive invalid data', CurrentTime());
            return;
          }
          // get socket object
          iosocket.forEach( function(client) {
            if (client.id === id) {
              console.log( '->%s: id=%s', CurrentTime(), client.id );
              client.emit( 'message', {"in":{"fm":mfrom},"data":data} );
            }
          });
        }
        else {
          console.log('%s: Can not get respond id', CurrentTime());
        }
      }
    }
    catch(err){
      console.error(err.message);
    }
  }

  var CurrentTime = function()
  {
    var currentdate = new Date(); 
    var datetime = currentdate.getFullYear() + "/" + currentdate.getMonth() + "/" + currentdate.getDate() + " ";
        datetime += currentdate.getHours() + ":" + currentdate.getMinutes() + ":" + currentdate.getSeconds() +":";
        datetime += currentdate.getMilliseconds();
    return datetime;
  }
}